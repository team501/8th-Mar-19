import React, { Component } from 'react';

import { connect } from 'react-redux';  // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component 

import { Link } from 'react-router-dom';
import Grid from '@material-ui/core/Grid';
import Assigned from './ChuteStatus/Assigned';
import AssignedPer from './ChuteStatus/AssignedPer';
import NotAssigned from './ChuteStatus/NotAssigned';
import Legends from './ChuteStatus/Legends';
import {Doughnut} from 'react-chartjs-2';
import DonutChart from 'Components/DonutChart/DonutChart';
// import DonutChart from 'react-donut-chart';

import './ChuteStatus/land.css';
import './ChuteStatus/label.css';

//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';

//json
import json from '../../assets/data/jsonDataConfig/Sorter/DoughnutChartConfig';

import {graphQlURLPrd} from '../../services/Config.js';
import DonutConfig from '../../assets/data/jsonDataConfig/UnitSorterMainDashboard/Sorter/chuteDonutConfig.json';
import axios from 'axios';

const mainGrid = {
    padding: '15px',
    height: '280px',
};


class ChuteStatusOverview extends Component {
    constructor(props) {
		super(props);
		this.state = {  sorterId: "",
			      		assigned: 0,
			      		chuteUtilization: 0,
			      		notAssigned: 1,
			      		assignedPercent: 75,
			      		details: [],
					    isLoading:true
					  };
	}
	
    /*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.getRecentOrders();
	}

	//Comparing props and triggering refresh 
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime) {
			this.getRecentOrders();
		}
	}
	
	getRecentOrders() {
		
		let query = `query GetChuteStatusDetails($startTime: Long!, $xMins: Int, $sorterId: String!) {
	    				getChuteStatusDetails(startTime: $startTime, xMins: $xMins, sorterId: $sorterId) {
	    					sorterId assigned chuteUtilization notAssigned assignedPercent
	    					details { label value percent }
	    			}
		}`;

		let startTime = 201903221245;//dateFormat(new Date(), "yyyymmddHHMM");
		let xMins = 1440;
		let sorterId = this.props.sorterId;


		fetch(graphQlURLPrd, {
			method: 'POST',
			headers: {
			'Content-Type': 'application/json',
			'Accept': 'application/json',
			},
			body: JSON.stringify({
				query,
				variables: { startTime, xMins, sorterId }
			})
		})
		.then(r => r.json())
		.then(data => { this.setState({ sorterId: data.data.getChuteStatusDetails.sorterId,
      									assigned: data.data.getChuteStatusDetails.assigned,
      									chuteUtilization: data.data.getChuteStatusDetails.chuteUtilization,
      									notAssigned: data.data.getChuteStatusDetails.notAssigned,
      									assignedPercent: data.data.getChuteStatusDetails.assignedPercent,
      									details: data.data.getChuteStatusDetails.details,
      									isLoading:false}); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ sorterId: "",
				      		assigned: 0,
				      		chuteUtilization: 0,
				      		notAssigned: 1,
				      		assignedPercent: 75,
				      		details: [],
						    isLoading:false
					 	}); 
		});
	}
    
    render () {
	
			var colors = DonutConfig.colors
			const { isColorBlind } = this.props;
			
			if(this.state.isLoading){
				return (<RctCollapsibleCard colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
											heading={"Chute Status"}
											fullBlock >
						</RctCollapsibleCard>);
			} else {
				
			}
			
            return(
                <RctCollapsibleCard colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
                					heading={"Chute Status"}
									fullBlock >
                    <Grid style={mainGrid} container>	
                        <Grid item xs={11} sm={11}>
							<DonutChart colors= {colors}
										innerRadius={DonutConfig.innerRadius}
										legend={DonutConfig.legend}
										clickToggle={DonutConfig.clickToggle}
										startAngle={DonutConfig.startAngle}
										toggledOffset={DonutConfig.toggledOffset}
										selectedOffset= {DonutConfig.selectedOffset}
										totalLabel={DonutConfig.totalLabel}
										colorBlindness={isColorBlind}
										data={this.state.details}
										total={this.state.chuteUtilization}
							/>
                        </Grid>
                       
						<div className="right-arrow-chute col-sm-1 col-md-1 col-lg-1" >
                            <Link to={{ pathname: `/app/dashboard/${this.props.nextLink}/chuteDetails`, state: { nextLink: this.props.nextLink } }}>
                                &#x203A;
                            </Link>
                        </div>
                    </Grid>
                    
                    <Grid className="chute-bottom-grid" container>
                        <Grid item xs={4} sm={4}>
                            <Assigned value={this.state.assigned}/>
                        </Grid>
                        <Grid item xs={4} sm={4}>
                            <NotAssigned value={this.state.notAssigned} />
                        </Grid>
                        <Grid item xs={4} sm={4}>
                            <AssignedPer value={this.state.assignedPercent} />
                        </Grid>
                    </Grid>				 
                </RctCollapsibleCard>
            );
    }
}

// map state to props
// Here we can fetch the value of isColorBlind as props
const mapStateToProps = ({ settings }) => {
	const { isColorBlind ,locale} = settings;
	console.log("isColorBlind value inside mapstateToProps -- "+ isColorBlind);
	return { isColorBlind,locale };
};

export default withRouter(connect(mapStateToProps)(ChuteStatusOverview));