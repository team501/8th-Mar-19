/**
 * Data Table
 */
import React from 'react';

import IconButton from '@material-ui/core/IconButton';
//axios call
import axios from 'axios';
import {baseURL} from '../../../services/Config.js';

// page title bar
import PageTitleBar from 'Components/PageTitleBar/PageTitleBar';

// rct card box
import { RctCard, RctCardContent } from 'Components/RctCard'; 

// intl messages
import IntlMessages from 'Util/IntlMessages';

//Reloadable card
import {WatchesWidget} from "Components/Widgets";

//Bootstrap datatable custom cell style
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import cellEditFactory from 'react-bootstrap-table2-editor';
import ToolkitProvider, { Search, CSVExport } from 'react-bootstrap-table2-toolkit';
	
class inductStatus extends React.Component {
	
	 constructor(props) {
    super(props);
	this.state = {  data: [],
					inductsVal: [],
					isLoading:true
				 };
	}
		
      
	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.onReload();
	}


	linkState = this.props.location.state === undefined ? '' : this.props.location.state.nextLink

	onReload = () => {
		axios.get(baseURL+'inductionstatus/'+ localStorage.getItem("user_id") )
			.then(res => {
				let inductsVal = res.data.map(list => list.inducts_per_hour);

				this.setState({ data: res.data,
								inductsVal: inductsVal,
								isLoading:false}); 
			}).catch(function (error) {
				console.log(error);
		});
	}

	
	render() {
		//Fetch Sorter ID from URL params
		const { sorterID } = this.props.match.params;
		
	    const rows = this.state.data; 
		
		const { match } = this.props;

		//Bootstrap datatable custom cell style
		const { SearchBar } = Search;
		const { ExportCSVButton } = CSVExport;
		const headerSortingStyle = { backgroundColor: '#c8e6c9' };
		const headerStyle = { fontWeight: 600, border:'none', backgroundColor: '#ffffff'};
		

		const sortCaret = (order, column) => {
				if (!order) return (<span class="order">&nbsp;&nbsp;<span class="dropdown"><span class="icon-arrow-up"></span></span><span class="dropup"><span class="icon-arrow-down"></span></span></span>);
				else if (order === 'asc') return (<span class="order">&nbsp;&nbsp;<span aria-hidden="true" class="icon-arrow-up"></span>&nbsp;&nbsp;&nbsp;&nbsp;</span>);
				else if (order === 'desc') return (<span class="order">&nbsp;&nbsp;<span aria-hidden="true" class="icon-arrow-down"></span>&nbsp;&nbsp;&nbsp;&nbsp;</span>);
				return null;
			};
			
		const columns = [
			{
				dataField: 'station',
				text: '',
				sort: false,
				style: (cell, row, rowIndex, colIndex) => {
					const backgroundColor = row.utilization > 10 && row.utilization <= 60 ? '#edad02' : row.utilization > 60 ? '#2ecc71' : '#ce5661';
					const color = '#ffffff';
					return { backgroundColor, color };
				},
				headerStyle 
			},
			{
				dataField: 'runtime',
				text: 'Runtime',
				sort: true,
				sortCaret,
				headerSortingStyle,
				headerStyle
			},
			{
				dataField: 'total_inducts',
				text: 'Total Inducts',
				sort: true,
				sortCaret,
				headerSortingStyle,
				headerStyle
			},
			{
				dataField: 'inducts_per_hour',
				text: 'Induct/hour',
				sort: true,
				sortCaret,
				headerSortingStyle,
				headerStyle
			},
			{
				dataField: 'utilization',
				text: 'Utilization',
				sort: true,
				sortCaret,
				headerSortingStyle,
				headerStyle,
				style: (cell, row, rowIndex, colIndex) => {
					const color = cell > 10 && cell <= 60 ? '#edad02' : cell > 60 ? '#2ecc71' : '#ce5661';
					return { color };
				},
				formatter: (cell, row) => {
					return (
						<span> { cell }%</span>
					);
				}
			},
			{
				dataField: 'peak_rate',
				text: 'Peak Rate',
				sort: true,
				sortCaret,
				headerSortingStyle,
				headerStyle
			},
			{
				dataField: 'min_rate',
				text: 'Min Rate',
				sort: true,
				sortCaret,
				headerSortingStyle,
				headerStyle
			},
			{
				dataField: 'avg_rate',
				text: 'Average Rate',
				sort: true,
				sortCaret,
				headerSortingStyle,
				headerStyle
			},
			{
				dataField: 'current_usr',
				text: 'Current user',
				sort: true,
				sortCaret,
				headerSortingStyle,
				headerStyle
			},
			{
				dataField: 'last_scan',
				text: 'Last Scan',
				sort: false,
				headerSortingStyle,
				headerStyle
			}
		];

		//Custom search results information
		const customTotal = (from, to, size) => (
			<span className="react-bootstrap-table-pagination-total">
				Showing { from } to { to } of { size } Results
			</span>
		);
		
		//Mock Data for Table
		const inducts = [
			{"id":2,"station":"Station A","runtime":"02:57","total_inducts":2100,"inducts_per_hour":1000,"utilization":10,"peak_rate":2000,"avg_rate":2500,"min_rate":3000,"current_usr":"xyz","last_scan":"2018-01-01 12:00:17","userid":"user1"},
			{"id":3,"station":"Station B","runtime":"02:57","total_inducts":2000,"inducts_per_hour":1000,"utilization":60,"peak_rate":2000,"avg_rate":2500,"min_rate":3000,"current_usr":"pqr","last_scan":"2018-01-01 12:00:17","userid":"user2"},
			{"id":4,"station":"Station C","runtime":"02:57","total_inducts":2000,"inducts_per_hour":1000,"utilization":79,"peak_rate":2000,"avg_rate":2500,"min_rate":3000,"current_usr":"xyz","last_scan":"2018-01-01 12:00:17","userid":"Ramesh"},
			{"id":5,"station":"Station A","runtime":"02:57","total_inducts":2000,"inducts_per_hour":1000,"utilization":20,"peak_rate":2000,"avg_rate":2500,"min_rate":3000,"current_usr":"xyz","last_scan":"2018-01-01 12:00:17","userid":"user1"},
			{"id":6,"station":"Station B","runtime":"02:57","total_inducts":2000,"inducts_per_hour":1000,"utilization":62,"peak_rate":2000,"avg_rate":2500,"min_rate":3000,"current_usr":"pqr","last_scan":"2018-01-01 12:00:17","userid":"user2"},
			{"id":7,"station":"Station C","runtime":"02:57","total_inducts":2000,"inducts_per_hour":1000,"utilization":77,"peak_rate":2000,"avg_rate":2500,"min_rate":3000,"current_usr":"xyz","last_scan":"2018-01-01 12:00:17","userid":"Ramesh"},
			{"id":8,"station":"Station A","runtime":"02:57","total_inducts":2000,"inducts_per_hour":1000,"utilization":14,"peak_rate":2000,"avg_rate":2500,"min_rate":3000,"current_usr":"xyz","last_scan":"2018-01-01 12:00:17","userid":"user1"},
			{"id":9,"station":"Station B","runtime":"02:57","total_inducts":2000,"inducts_per_hour":1000,"utilization":64,"peak_rate":2000,"avg_rate":2500,"min_rate":3000,"current_usr":"pqr","last_scan":"2018-01-01 12:00:17","userid":"user2"},
			{"id":10,"station":"Station C","runtime":"02:57","total_inducts":2000,"inducts_per_hour":1000,"utilization":75,"peak_rate":2000,"avg_rate":2500,"min_rate":3000,"current_usr":"xyz","last_scan":"2018-01-01 12:00:17","userid":"Ramesh"},
			{"id":12,"station":"Station A","runtime":"02:57","total_inducts":2000,"inducts_per_hour":1000,"utilization":16,"peak_rate":2000,"avg_rate":2500,"min_rate":3000,"current_usr":"xyz","last_scan":"2018-01-01 12:00:17","userid":"user1"},
			{"id":13,"station":"Station B","runtime":"02:57","total_inducts":2000,"inducts_per_hour":1000,"utilization":66,"peak_rate":2000,"avg_rate":2500,"min_rate":3000,"current_usr":"pqr","last_scan":"2018-01-01 12:00:17","userid":"user2"},
			{"id":14,"station":"Station C","runtime":"02:57","total_inducts":2000,"inducts_per_hour":1000,"utilization":85,"peak_rate":2000,"avg_rate":2500,"min_rate":3000,"current_usr":"xyz","last_scan":"2018-01-01 12:00:17","userid":"Ramesh"},
			{"id":15,"station":"Station A","runtime":"02:57","total_inducts":2000,"inducts_per_hour":1000,"utilization":18,"peak_rate":2000,"avg_rate":2500,"min_rate":3000,"current_usr":"xyz","last_scan":"2018-01-01 12:00:17","userid":"user1"},
			{"id":16,"station":"Station B","runtime":"02:57","total_inducts":2000,"inducts_per_hour":1000,"utilization":68,"peak_rate":2000,"avg_rate":2500,"min_rate":3000,"current_usr":"pqr","last_scan":"2018-01-01 12:00:17","userid":"user2"},
			{"id":17,"station":"Station C","runtime":"02:57","total_inducts":2000,"inducts_per_hour":1000,"utilization":89,"peak_rate":2000,"avg_rate":2500,"min_rate":3000,"current_usr":"xyz","last_scan":"2018-01-01 12:00:17","userid":"Ramesh"}
		];

		//Defininf options for pagination
		const options = {
			paginationSize: 4,
			pageStartIndex: 1,
			alwaysShowAllBtns: true, // Always show next and previous button
			withFirstAndLast: true, // Hide the going to First and Last page button
			hideSizePerPage: true, // Hide the sizePerPage dropdown always
			hidePageListOnlyOnePage: true, // Hide the pagination list when only one page
			firstPageText: 'First',
			prePageText: 'Prev',
			nextPageText: 'Next',
			lastPageText: 'Last',
			nextPageTitle: 'First page',
			prePageTitle: 'Prev page',
			firstPageTitle: 'Next page',
			lastPageTitle: 'Last page',
			showTotal: true,
			paginationTotalRenderer: customTotal,
			sizePerPageList: [
				{
					text: '25', value: 25 //number of results per page
				}
			] // A numeric array is also available. the purpose of above example is custom the text
		};
		
		//Custom Reload button for data rerendering
		const ReloadButton = () => {
			return (
			  <div>
				<button className="btn pull-right" onClick={() => this.onReload()}>
					<span aria-hidden="true" class="icon-reload"></span>
				</button>
			  </div>
			);
		  };

		return (
			<div className="data-table-wrapper">
				<PageTitleBar 
					url={`/app/dashboard/sorterDetails/${sorterID}`} 
					title={<IntlMessages id="sidebar.inductStatusTable" />} 
					match={match} 
				/>
				<RctCard>
		        <RctCardContent>
					<ToolkitProvider
						keyField="id"
						data={ inducts }
						columns={ columns }
						search
						exportCSV 
						>
						{
							props => (
							<div>
								<ReloadButton { ...props.searchProps } />
								<SearchBar
								{ ...props.searchProps }
								className="custome-search-field"
								style={ { color: 'black' } }
								delay={ 1000 }
								placeholder="Search"
								/>
								<BootstrapTable
								{ ...props.baseProps }
								bordered={ false }
								striped
								hover
								condensed
								pagination={ paginationFactory(options) }
								/>
							</div>
							)
						}
					</ToolkitProvider>
				</RctCardContent>
			</RctCard >
		</div>
		);
	}
}

export default inductStatus;
